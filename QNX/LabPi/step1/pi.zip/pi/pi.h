#ifndef PI_H_
#define PI_H_

	// declaration of C-data and functions are inserted here. E.g.,
	int myPi(int argc, char *argv[]);

#endif /*PI_H_*/
